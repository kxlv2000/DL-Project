import wandb
import torch
import pandas as pd
import torch.nn as nn
import numpy as np
import os

from sklearn.model_selection import train_test_split
from preprocess import tokenize, padding_
from torch.utils.data import TensorDataset, DataLoader
from model import SentimentRNN
from regularization import li_reg, elastic_net_reg

exp_name = 'drop_sweep'

# sweep configuration
sweep_configuration = {
    'method': 'grid',
    'metric': {'goal': 'maximize', 'name': 'val_accuracy.max'},
    'parameters': {
        'batch_size': {'value': 1250},
        'epochs': {'value': 10},
        'learning_rate': {'value': 0.001},
        'drop_prob':{'values': [0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]},
        'weight_decay': {'value': 0},
        # 'l1_weight': {'values': [0.0, 1e-10, 5e-10, 1e-9, 5e-9, 1e-8, 5e-8, 1e-7, 5e-7, 1e-6, 5e-6, 1e-5, 5e-5, 1e-4, 5e-4, 1e-3]},
        # 'l2_weight': {'values': [0.0, 1e-10, 5e-10, 1e-9, 5e-9, 1e-8, 5e-8, 1e-7, 5e-7, 1e-6, 5e-6, 1e-5, 5e-5]},
        # 'en_weights':{'value': 0}
    }
}

# function to predict accuracy
def acc(pred,label):
    pred = torch.round(pred.squeeze())
    return torch.sum(pred == label.squeeze()).item()

def main():    
    wandb.init(project="LSTM", name=exp_name)
    # define a metric we are interested in the minimum of
    wandb.define_metric("val_loss", summary="min")
    # define a metric we are interested in the maximum of
    wandb.define_metric("val_accuracy", summary="max")

    # fix random seeds
    torch.manual_seed(0)
    np.random.seed(0)
    torch.use_deterministic_algorithms(True)

    is_cuda = torch.cuda.is_available()

    # If we have a GPU available, we'll set our device to GPU. We'll use this device variable later in our code.
    if is_cuda:
        device = torch.device("cuda")
        print("GPU is available")
    else:
        device = torch.device("cpu")
        print("GPU not available, CPU used")

    base_csv = 'input/IMDB Dataset.csv'
    df = pd.read_csv(base_csv)

    ### Splitting to train and test data
    X, y = df['review'].values, df['sentiment'].values
    x_train, x_test, y_train, y_test = train_test_split(X, y, stratify = y)
    print(f'shape of train data is {x_train.shape}')
    print(f'shape of test data is {x_test.shape}')

    ### Tokenization
    x_train, y_train, x_test, y_test, vocab = tokenize(x_train, y_train, x_test, y_test)
    print(f'Length of vocabulary is {len(vocab)}')

    ### Padding
    # we have very less number of reviews with length > 500.
    # So we will consideronly those below it.
    x_train_pad = padding_(x_train, 500)
    x_test_pad = padding_(x_test, 500)

    ### Batching and loading as tensor
    # create Tensor datasets
    train_data = TensorDataset(torch.from_numpy(x_train_pad), torch.from_numpy(y_train))
    valid_data = TensorDataset(torch.from_numpy(x_test_pad), torch.from_numpy(y_test))

    # dataloaders

    # make sure to SHUFFLE your data
    train_loader = DataLoader(train_data, shuffle=True, batch_size=wandb.config.batch_size, drop_last=True)
    valid_loader = DataLoader(valid_data, shuffle=True, batch_size=wandb.config.batch_size, drop_last=True)

    ### Model
    # no_layers = 2
    # vocab_size = len(vocab) + 1 #extra 1 for padding
    # embedding_dim = 64
    # output_dim = 1
    # hidden_dim = 256
    model = SentimentRNN(2, len(vocab) + 1, 256, 64, 1, drop_prob=wandb.config.drop_prob)

    # moving to gpu
    model.to(device)

    print(model)

    ### Training
    # loss and optimization functions
    criterion = nn.BCELoss()

    optimizer = torch.optim.Adam(
        model.parameters(), 
        lr=wandb.config.learning_rate, 
        weight_decay=wandb.config.weight_decay)


    clip = 5
    valid_loss_min = np.Inf
    # train for some number of epochs
    epoch_tr_loss,epoch_vl_loss = [],[]
    epoch_tr_acc,epoch_vl_acc = [],[]

    for epoch in range(wandb.config['epochs']):
        train_losses = []
        train_acc = 0.0
        model.train()
        # initialize hidden state 
        h = model.init_hidden(wandb.config.batch_size, device)
        for inputs, labels in train_loader:

            inputs, labels = inputs.to(device), labels.to(device)   
            # Creating new variables for the hidden state, otherwise
            # we'd backprop through the entire training history
            h = tuple([each.data for each in h])

            model.zero_grad()
            output,h = model(inputs,h)

            # calculate the loss and perform backprop
            loss = criterion(output.squeeze(), labels.float())
            # loss += li_reg(model, wandb.config.l1_weight, i=1)
            # loss += li_reg(model, wandb.config.l2_weight, i=2)
            # loss += elastic_net_reg(model, wandb.config.en_weights)

            loss.backward()
            train_losses.append(loss.item())
            # calculating accuracy
            accuracy = acc(output,labels)
            train_acc += accuracy
            #`clip_grad_norm` helps prevent the exploding gradient problem in RNNs / LSTMs.
            nn.utils.clip_grad_norm_(model.parameters(), clip)
            optimizer.step()
    


        val_h = model.init_hidden(wandb.config.batch_size, device)
        val_losses = []
        val_acc = 0.0
        model.eval()
        for inputs, labels in valid_loader:
                val_h = tuple([each.data for each in val_h])

                inputs, labels = inputs.to(device), labels.to(device)

                output, val_h = model(inputs, val_h)
                val_loss = criterion(output.squeeze(), labels.float())

                val_losses.append(val_loss.item())

                accuracy = acc(output,labels)
                val_acc += accuracy

        epoch_train_loss = np.mean(train_losses)
        epoch_val_loss = np.mean(val_losses)
        epoch_train_acc = train_acc/len(train_loader.dataset)
        epoch_val_acc = val_acc/len(valid_loader.dataset)
        epoch_tr_loss.append(epoch_train_loss)
        epoch_vl_loss.append(epoch_val_loss)
        epoch_tr_acc.append(epoch_train_acc)
        epoch_vl_acc.append(epoch_val_acc)
        print(f'Epoch {epoch+1}') 
        print(f'train_loss : {epoch_train_loss} val_loss : {epoch_val_loss}')
        print(f'train_accuracy : {epoch_train_acc*100} val_accuracy : {epoch_val_acc*100}')
        if epoch_val_loss <= valid_loss_min:
            torch.save(model.state_dict(), 'working/state_dict.pth')
            print('Validation loss decreased ({:.6f} --> {:.6f}).  Saving model ...'.format(valid_loss_min,epoch_val_loss))
            valid_loss_min = epoch_val_loss
        wandb.log({
            'train_loss' : epoch_train_loss, 
            'val_loss' : epoch_val_loss, 
            'train_accuracy' : epoch_train_acc*100, 
            'val_accuracy' : epoch_val_acc*100})
        print(25*'==')

if __name__ == '__main__':
    os.environ['CUBLAS_WORKSPACE_CONFIG'] = ':4096:8'

    wandb.login()
    # main()

    # Start sweep job.
    sweep_id = wandb.sweep(sweep=sweep_configuration, project="LSTM")
    wandb.agent(sweep_id, function = main)