import torch

def li_reg(model, factor, i):
    '''
    LLoss, 只惩罚含有 weight 的参数
    model: 传入模型
    factor: 正则化惩罚系数
    i: i-范数
    '''
    reg_loss = torch.tensor(0.,)
    for name, w in model.named_parameters():
        if 'weight' in name:    # 只对 参数名 含有 weight 的参数 正则化
            reg_loss = reg_loss + torch.norm(w, i)
    reg_loss = factor * reg_loss
    return reg_loss

def  elastic_net_reg(model, factor):
    l1_reg = li_reg(model, factor, 1)
    l2_reg = li_reg(model, 1-factor, 2)
    return l1_reg + l2_reg